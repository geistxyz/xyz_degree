/*
 * Commnad.java
 */
package edu.umss.devportal.plugins.scm.command;

/**
 * Executes a command
 * @author Arminda Yovana Soto
 */
public interface Command {

    public void execute();
}
