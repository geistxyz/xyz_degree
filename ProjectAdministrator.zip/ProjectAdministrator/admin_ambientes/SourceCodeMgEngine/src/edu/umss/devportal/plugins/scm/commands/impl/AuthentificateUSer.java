/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.umss.devportal.plugins.scm.commands.impl;

/**
 *
 * @author Arminda Yovana Soto
 */
public class AuthentificateUSer {

}
