///*
// * To change this template, choose Tools | Templates
// * and open the template in the editor.
// */
//
//package edu.umss.devportal.plugins.dummy;
//
//import org.junit.After;
//import org.junit.AfterClass;
//import org.junit.Before;
//import org.junit.BeforeClass;
//import org.junit.runner.RunWith;
//import org.junit.runners.Suite;
//
///**
// *
// * DummyPlugin Test Suite, in charge of run all tests for DummyPlugin
// *
// * @author raul lopez
// * @version 1.0
// */
//@RunWith(Suite.class)
//@Suite.SuiteClasses({edu.umss.devportal.plugins.dummy.IdGeneratorTest.class,edu.umss.devportal.plugins.dummy.DummyProjectTrackerTest.class})
//public class DummyPluginTestSuite {
//
//    @BeforeClass
//    public static void setUpClass() throws Exception {
//    }
//
//    @AfterClass
//    public static void tearDownClass() throws Exception {
//    }
//
//    @Before
//    public void setUp() throws Exception {
//    }
//
//    @After
//    public void tearDown() throws Exception {
//    }
//
//}