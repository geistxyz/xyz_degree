/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.umss.devportal.plugins.xplanner.reports.structure;

/**
 *
 * @author Grace
 */
public enum TaskColumn {
    ID, LAST_UPDATE, NAME, TYPE, DESCRIPTION, ACCEPTOR_ID,CREATED_DATE,
    ESTIMATED_HOURS,ORIGINAL_ESTIMATE,IS_COMPLETE,STORY_ID,DISPOSITION
}
