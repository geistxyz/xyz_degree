/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.umss.devportal.plugins.xplanner.connection;

/**
 *
 * @author Raul Lopez
 */
public enum XPlannerConnectionType {
    WebService
}
