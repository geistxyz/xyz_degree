/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.umss.devportal.plugins.xplanner.reports.structure;

/**
 *
 * @author Grace
 */
public enum TimeEntryColumn {
    ID,LAST_UPDATE,START_TIME,END_TIME,DURATION,PERSON1_ID,
    PERSON2_ID,TASK_ID,REPORT_DATE,DESCRIPTION
}
