/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.umss.devportal.plugins.xplanner.reports.structure;

/**
 *
 * @author Grace
 */
public enum IterationColumn {
    ID,LAST_UPDATE,PROJECT_ID,NAME,DESCRIPTION,
    START_DATE,END_DATE,STATUS,DAYS_WORKED
}
