/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.umss.devportal.plugins.xplanner.reports.structure;

/**
 *
 * @author Grace
 */
public enum UserStoryColumn {
ID,LAST_UPDATE,NAME,DESCRIPTION,ITERATION_ID,TRACKER_ID,ESTIMATED_HOURS,
PRIORITY,CUSTOMER_ID,STATUS,ORIGINAL_ESTIMATED_HOURS,DISPOSITION,
POSTPONED_HOURS,IT_START_ESTIMATED_HOURS,ORDERNO
}
