/*
 *  @(#)PluginDoesNotFoundException.java   21-nov-2010
 */

package edu.umss.devportal.plugins.exceptions;

/**
 *
 * @author Alex Arenas
 */
public class PluginDoesNotFoundException extends Exception{

    //TODO implement constructors
}
