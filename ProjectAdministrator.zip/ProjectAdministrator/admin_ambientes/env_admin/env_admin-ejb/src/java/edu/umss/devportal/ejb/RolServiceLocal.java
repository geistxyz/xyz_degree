/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.umss.devportal.ejb;

import javax.ejb.Local;

/**
 *
 * @author Roger Ayaviri
 */
@Local
public interface RolServiceLocal {
    
}
