/*
 *  @(#)PluginDescriptorNotFoundException.java   21-nov-2010
 */

package edu.umss.devportal.plugins.exceptions;

/**
 *
 * @author Alex Arenas
 */
public class PluginDescriptorNotFoundException extends Exception{
    //TODO implement constructors
}
