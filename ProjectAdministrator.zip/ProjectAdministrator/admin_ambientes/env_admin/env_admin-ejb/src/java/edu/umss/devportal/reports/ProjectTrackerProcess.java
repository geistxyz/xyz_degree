/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.umss.devportal.reports;

import java.util.List;
import java.util.ArrayList;
import edu.umss.devportal.common.reports.DataStructure;
import java.util.Properties;

/**
 *
 * @author user
 */
public class ProjectTrackerProcess {

    // MockReportsXplanner mockObj;

    public ProjectTrackerProcess() {
       //  mockObj = new MockReportsXplanner();
    }

    List<List<String>> getResult(Properties query) {
        //TODO  Here will be a other type of proc to determine
        // which report return
        List<List<String>> result = new ArrayList<List<String>>();

        return result;
    }
}
