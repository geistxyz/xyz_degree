/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.umss.devportal.plugins.exceptions;

/**
 *
 * @author chelo
 */
public class PluginNotInstalledException extends Exception{
    //TODO implement constructors.
}
