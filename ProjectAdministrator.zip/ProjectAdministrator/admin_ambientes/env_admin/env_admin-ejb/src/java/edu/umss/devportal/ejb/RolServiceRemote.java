/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.umss.devportal.ejb;

import javax.ejb.Remote;

/**
 *
 * @author Roger Ayaviri
 */
@Remote
public interface RolServiceRemote {
    
}
