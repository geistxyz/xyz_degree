package edu.umss.devportal.ejb;
import javax.ejb.Local;

@Local
public interface ToolServiceLocal {

}
