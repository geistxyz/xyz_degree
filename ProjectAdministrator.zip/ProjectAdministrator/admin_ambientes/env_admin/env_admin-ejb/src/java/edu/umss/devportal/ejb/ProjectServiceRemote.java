package edu.umss.devportal.ejb;
import javax.ejb.Remote;

@Remote
public interface ProjectServiceRemote {

}
