/*
 *  @(#)PluginManagerNotFoundException.java   21-nov-2010
 */

package edu.umss.devportal.plugins.exceptions;

/**
 *
 * @author Alex Arenas
 */
public class PluginManagerNotFoundException extends Exception{
    //TODO add constructors
}
