/*
 * @(#)ReportBackingBean.java 11/04/21
 *
 * Copyright (c) 2011 Universidad Mayor de San Simón
 * Cochabamba - Bolivia
 * All Rights Reserved.
 */

package edu.umss.devportal.reports.backbeans;

/**
 *
 * @author Edson
 */
public class ReportBackingBean {

}
