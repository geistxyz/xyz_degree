/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.umss.devportal.common;

import edu.umss.devportal.common.reports.DynamicStructure;

/**
 *
 * @author Edson
 */
public interface VersionControlTracker extends ToolPlugin{
    
}
