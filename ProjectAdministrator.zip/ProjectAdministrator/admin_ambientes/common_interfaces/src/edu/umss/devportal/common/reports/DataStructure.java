/*
 * @(#)DataStructure.java
 */

package edu.umss.devportal.common.reports;

/**
 *
 * @author Edson
 * @version 1.0
 */
public interface DataStructure {

}
